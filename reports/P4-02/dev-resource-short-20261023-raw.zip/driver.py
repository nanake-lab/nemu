"""Development-only 240-second resource probe; never formal acceptance."""
import inspect
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / 'services/voice-sidecar'))
import benchmark
source = inspect.getsource(benchmark.measure)
source = source.replace('async def measure(', 'async def development_measure(')
source = source.replace('while time.monotonic() - stress_start < 1800:', 'while time.monotonic() - stress_start < 240:')
source = source.replace('assessment = assess(pressure)', 'assessment = {"acceptance": False, "extension_required": False, "note": "240-second development observation only; 20-30 minute policy is not assessed"}')
source = source.replace('return results', 'results["acceptance"] = False\n        return results')
namespace = dict(vars(benchmark))
exec(compile(source, __file__, 'exec'), namespace)
benchmark.main(namespace['development_measure'])
