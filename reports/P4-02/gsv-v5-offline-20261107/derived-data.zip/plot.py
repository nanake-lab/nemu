import os
os.environ['MPLBACKEND'] = 'Agg'
os.environ['MPLCONFIGDIR'] = r'D:\Dev\cache\p4-02\gsv-v5-offline-20261107\mpl-cache'
os.environ['CUDA_VISIBLE_DEVICES'] = ''
import json
from pathlib import Path
import matplotlib.pyplot as plt
base = Path(__file__).parent
summary = json.loads((base/'summary.json').read_text(encoding='utf-8'))
start = summary['stability']['start_utc']
end = summary['stability']['end_utc']
rows = [json.loads(line) for line in (base/'memory-derived.jsonl').read_text(encoding='utf-8').splitlines()]
rows = [r for r in rows if start <= r['utc'] <= end]
fig, axes = plt.subplots(4, 1, figsize=(10, 8), sharex=True)
for ax, key, label in zip(axes, ('dedicated','shared','rss','private'), ('TTS dedicated GPU memory','TTS shared GPU memory','TTS working set (RSS)','TTS private commit')):
    ax.plot([(r['utc']-start)/60 for r in rows], [r[key]/1048576 for r in rows], color='#205b8f', linewidth=.7)
    ax.axvspan(0, 3, color='gray', alpha=.12)
    ax.axvspan(27, 30, color='gray', alpha=.12)
    ax.set_ylabel('MiB')
    ax.set_title(label, loc='left', fontsize=10)
    ax.grid(alpha=.2)
    ax.ticklabel_format(useOffset=False, style='plain', axis='y')
axes[-1].set_xlabel('Minutes since continuous synthesis started')
axes[-1].set_xlim(0,30.02)
fig.suptitle('Standalone GPT-SoVITS V5: 1800.56 s / 2016 requests\nObserved process-tree samples; axes have separate scales', fontsize=12)
fig.tight_layout()
fig.savefig(base/'memory-trends.png', dpi=150)
plt.close(fig)
