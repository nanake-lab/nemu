"""Development retest: original 512-frame WS workload, 240 seconds only."""
import inspect
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'nemu-wt/P4-02/services/voice-sidecar'))
import benchmark
source = inspect.getsource(benchmark.measure)
source = source.replace('async def measure(', 'async def development_measure(')
source = source.replace('while time.monotonic() - stress_start < 1800:', 'while time.monotonic() - stress_start < 240:')
source = source.replace('assessment = assess(pressure)', 'assessment = {"acceptance": False, "extension_required": False, "note": "240-second development retest; formal 20-30-minute policy is not assessed"}')
source = source.replace('return results', 'results["acceptance"] = False\n        return results')
namespace = dict(vars(benchmark))
exec(compile(source, __file__, 'exec'), namespace)
benchmark.main(namespace['development_measure'])
